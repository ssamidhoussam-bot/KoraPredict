const { onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
initializeApp();
const db = getFirestore();

// Admin-only match updates trigger scoring on the server.
// The client cannot write earned points or user totals.
exports.scoreFinishedMatch = onDocumentUpdated("matches/{matchId}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (!before || !after || before.status === "finished" || after.status !== "finished") return;
  if (!Number.isInteger(after.homeScore) || !Number.isInteger(after.awayScore)) return;

  const snap = await db.collection("predictions").where("matchId", "==", event.params.matchId).get();
  const batch = db.batch();
  for (const doc of snap.docs) {
    const p = doc.data();
    let earned = 0;
    if (p.home === after.homeScore && p.away === after.awayScore) earned = 5;
    else {
      const predicted = Math.sign(p.home - p.away);
      const actual = Math.sign(after.homeScore - after.awayScore);
      if (predicted === actual) earned = 3;
    }
    batch.update(doc.ref, { earned, scoredAt: FieldValue.serverTimestamp() });
    batch.set(db.collection("users").doc(p.uid), {
      points: FieldValue.increment(earned)
    }, { merge: true });
  }
  await batch.commit();
});
