import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Run `flutterfire configure` to generate firebase_options.dart, then
  // initialize with DefaultFirebaseOptions.currentPlatform.
  await Firebase.initializeApp();
  runApp(const KoraPredictApp());
}

class KoraPredictApp extends StatelessWidget {
  const KoraPredictApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'KoraPredict',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff1769aa)),
      scaffoldBackgroundColor: const Color(0xfff3f6fa),
      useMaterial3: true,
    ),
    home: const AuthGate(),
  );
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}
class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  String? error;
  @override
  void initState() {
    super.initState();
    _signIn();
  }
  Future<void> _signIn() async {
    try {
      // Anonymous account is a safe onboarding placeholder. Add verified
      // email/phone sign-in before public launch.
      if (FirebaseAuth.instance.currentUser == null) {
        await FirebaseAuth.instance.signInAnonymously();
      }
    } catch (e) {
      error = 'تعذر الاتصال بخدمة الحسابات. تحقق من إعداد Firebase.';
    }
    if (mounted) setState(() => loading = false);
  }
  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) return Scaffold(body: Center(child: Text(error!, textDirection: TextDirection.rtl)));
    return const HomePage();
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  final db = FirebaseFirestore.instance;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  Future<void> predict(String matchId, int home, int away) async {
    if (home < 0 || away < 0 || home > 20 || away > 20) {
      _message('أدخل نتيجة بين 0 و20');
      return;
    }
    try {
      await db.collection('predictions').doc('${matchId}_$uid').set({
        'matchId': matchId,
        'uid': uid,
        'home': home,
        'away': away,
        'createdAt': FieldValue.serverTimestamp(),
      });
      _message('تم حفظ توقعك');
    } on FirebaseException catch (e) {
      _message(e.code == 'permission-denied'
          ? 'انتهى وقت التوقع أو أن المباراة غير متاحة.'
          : 'تعذر حفظ التوقع. حاول لاحقاً.');
    }
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text, textDirection: TextDirection.rtl)));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _matches(),
      _leaderboard(),
      _myPredictions(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('⚽ KoraPredict', style: TextStyle(fontWeight: FontWeight.bold)),
          backgroundColor: const Color(0xff102a43),
          foregroundColor: Colors.white,
        ),
        body: pages[tab],
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.sports_soccer), label: 'المباريات'),
            NavigationDestination(icon: Icon(Icons.leaderboard), label: 'الترتيب'),
            NavigationDestination(icon: Icon(Icons.history), label: 'توقعاتي'),
          ],
        ),
      ),
    );
  }

  Widget _matches() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: db.collection('matches').where('status', isEqualTo: 'open')
      .orderBy('kickoff').snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return const Center(child: Text('خطأ في تحميل المباريات'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snap.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('لا توجد مباريات متاحة حالياً'));
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Card(child: Padding(
            padding: EdgeInsets.all(12),
            child: Text('توقع النتيجة قبل انطلاق المباراة واجمع النقاط. لا توجد مراهنات أو إيداعات.',
              textDirection: TextDirection.rtl),
          )),
          ...docs.map((d) => MatchCard(data: d.data(), onPredict: (h, a) => predict(d.id, h, a))),
        ],
      );
    },
  );

  Widget _leaderboard() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: db.collection('users').orderBy('points', descending: true).limit(50).snapshots(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      return ListView(padding: const EdgeInsets.all(12), children: [
        const Text('أفضل اللاعبين', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ...snap.data!.docs.asMap().entries.map((entry) {
          final u = entry.value.data();
          return Card(child: ListTile(
            leading: CircleAvatar(child: Text('${entry.key + 1}')),
            title: Text((u['displayName'] ?? 'لاعب').toString()),
            trailing: Text('${u['points'] ?? 0} نقطة'),
          ));
        }),
      ]);
    },
  );

  Widget _myPredictions() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: db.collection('predictions').where('uid', isEqualTo: uid)
      .orderBy('createdAt', descending: true).snapshots(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      if (snap.data!.docs.isEmpty) return const Center(child: Text('لم تحفظ أي توقع بعد'));
      return ListView(children: snap.data!.docs.map((d) {
        final p = d.data();
        return Card(child: ListTile(
          title: Text('توقعك: ${p['home']} - ${p['away']}'),
          subtitle: Text('المباراة: ${p['matchId']}'),
          trailing: Text('${p['earned'] ?? 0} نقطة'),
        ));
      }).toList());
    },
  );
}

class MatchCard extends StatefulWidget {
  const MatchCard({super.key, required this.data, required this.onPredict});
  final Map<String, dynamic> data;
  final Future<void> Function(int, int) onPredict;
  @override
  State<MatchCard> createState() => _MatchCardState();
}
class _MatchCardState extends State<MatchCard> {
  final home = TextEditingController();
  final away = TextEditingController();
  @override
  void dispose() { home.dispose(); away.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    final kickoff = d['kickoff'] is Timestamp
      ? (d['kickoff'] as Timestamp).toDate().toLocal().toString()
      : 'موعد غير محدد';
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 7),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Text('${d['competition'] ?? 'مباراة'} • $kickoff',
            style: Theme.of(context).textTheme.labelSmall),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Expanded(child: Text('${d['homeTeam'] ?? 'الفريق الأول'}', textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold))),
            const Text('VS', style: TextStyle(color: Colors.grey)),
            Expanded(child: Text('${d['awayTeam'] ?? 'الفريق الثاني'}', textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold))),
          ]),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            SizedBox(width: 62, child: TextField(controller: home, keyboardType: TextInputType.number,
              textAlign: TextAlign.center, decoration: const InputDecoration(hintText: '0', border: OutlineInputBorder()))),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text(':')),
            SizedBox(width: 62, child: TextField(controller: away, keyboardType: TextInputType.number,
              textAlign: TextAlign.center, decoration: const InputDecoration(hintText: '0', border: OutlineInputBorder()))),
          ]),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: () {
              final h = int.tryParse(home.text), a = int.tryParse(away.text);
              if (h == null || a == null) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل النتيجة أولاً')));
                return;
              }
              widget.onPredict(h, a);
            },
            child: const Text('حفظ التوقع'),
          ),
        ]),
      ),
    );
  }
}
